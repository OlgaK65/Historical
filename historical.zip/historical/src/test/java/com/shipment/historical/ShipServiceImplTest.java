package com.shipment.historical;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertTrue;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import com.shipment.historical.model.ShipDate;
import com.shipment.historical.model.ShipInterval;
import com.shipment.historical.model.ShipPoint;
import com.shipment.historical.service.ShipService;
import com.shipment.historical.service.ShipServiceImpl;

public class ShipServiceImplTest {

	
	private ShipService shipService = new ShipServiceImpl();
	List<ShipInterval> ls = new ArrayList<>();
	List<ShipPoint> sp = new ArrayList<>(); 
	List<Integer> vessels = Arrays.asList(1,2,3);
	Set<ShipPoint> shp = new HashSet<>();
		
	@BeforeEach
	public void setUp() {
			
//		(A, 1, NY, ANWERP, 1/1, 14/1)
//		(A, 2, ANTWERP, HAIFA, 14/1, 20/1)
//		(B, 2, ANTWERP, HAIFA, 14/1, 20/1)
//		(B, 3, HAIFA, ASHDOD, 20/1, 21/1)
//		(C, 2, HAIFA, ANTWERP, 20/1, 26/1)
//		(D, 3, ASHDOD, KOBE, 24/1, 10/2)
	
		ls.add(new ShipInterval("A", 1, "NY", "ANWERP", new ShipDate(1,1), new ShipDate(14,1)));
		ls.add(new ShipInterval("A", 2, "ANWERP", "HAIFA", new ShipDate(14,1), new ShipDate(20,1)));
		ls.add(new ShipInterval("B", 2, "ANWERP", "HAIFA", new ShipDate(14,1), new ShipDate(20,1)));
		ls.add(new ShipInterval("B", 3, "HAIFA", "ASHDOD", new ShipDate(20,1), new ShipDate(21,1)));
		ls.add(new ShipInterval("C", 2, "HAIFA", "ANWERP", new ShipDate(20,1), new ShipDate(26,1)));
		ls.add(new ShipInterval("D", 3, "ASHDOD", "KOBE", new ShipDate(24,1), new ShipDate(10,2)));
		
//		(1, 1/1, 14/1)
//		(2, 14/1, 26/1)
//		(3, 20/1, 21/1)
//		(3, 24/1, 10/2)
	
		sp.add(new ShipPoint(1, new ShipDate(1,1), new ShipDate(14,1)));
		sp.add(new ShipPoint(2, new ShipDate(14,1), new ShipDate(26,1)));
		sp.add(new ShipPoint(3, new ShipDate(20,1), new ShipDate(21,1)));
		sp.add(new ShipPoint(3, new ShipDate(24,1), new ShipDate(10,2)));
			
	}
	
	@Test
	public void testShipServiceImpl() {
		shipService.createMap(ls, "1/1", "10/2");
		
		for(Integer i: vessels){
			shp.addAll(shipService.getHistoricalAisData(i, "1/1", "10/2"));			
		}	
		
		assertEquals(shp.size(),4);
		assertTrue(shp.contains(sp.get(1)));
		assertTrue(shp.contains(sp.get(3)));
	}	
		
}
