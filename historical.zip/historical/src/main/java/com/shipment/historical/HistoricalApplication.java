package com.shipment.historical;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class HistoricalApplication {

	public static void main(String[] args) {
		SpringApplication.run(HistoricalApplication.class, args);
	}

}
