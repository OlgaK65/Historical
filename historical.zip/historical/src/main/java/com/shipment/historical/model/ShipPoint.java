package com.shipment.historical.model;

import java.util.Comparator;

import com.fasterxml.jackson.annotation.JsonIgnore;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter

public class ShipPoint {
	Integer vessel;
	ShipDate start;
	ShipDate end;
	
	@JsonIgnore
	Comparator<ShipPoint> startDate = (o1, o2) -> o1.getStart().compareTo(o2.getStart());
	
	@JsonIgnore
	Comparator<ShipPoint> endDate = (o1, o2) -> o1.getEnd().compareTo(o2.getEnd());
	
	public ShipPoint(ShipPoint sp0, ShipPoint sp1){
		if(sp0 != null) {
			this.vessel = sp0.getVessel();
			this.start = sp0.getStart();
		}	
		
		if(sp1 != null)
			this.end = sp1.getEnd();		 
	}
	
	public ShipPoint(Integer vessel, ShipDate start, ShipDate end){
		this.vessel = vessel;
		this.start = new ShipDate(start);
		this.end = new ShipDate(end);
	}
}
