package com.shipment.historical.service;

import java.util.List;
import java.util.Set;

import com.shipment.historical.model.ShipInterval;
import com.shipment.historical.model.ShipPoint;

public interface ShipService {
	
	Set<ShipPoint> getHistoricalAisData(int vessel, String start, String end);
	void createMap(List<ShipInterval> shipIntervals, String start, String end);
	Set<Integer> getMapKeys();
}
