package com.shipment.historical.service;

import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.HashSet;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;
import java.util.Set;

import org.springframework.stereotype.Service;

import com.shipment.historical.model.ShipDate;
import com.shipment.historical.model.ShipInterval;
import com.shipment.historical.model.ShipPoint;

@Service
public class ShipServiceImpl implements ShipService {

	Map<Integer, List<List<ShipPoint>>> shipMap = new HashMap<>();
	
	@Override
	public Set<Integer> getMapKeys(){
		return  shipMap.keySet();
	}
	
	@Override
	public void createMap(List<ShipInterval> shipIntervals, String start, String end){
		
		shipMap.clear();
		shipIntervals.forEach(si -> putShipPoint(si));
	}
	
	@Override
	public Set<ShipPoint> getHistoricalAisData(int vessel, String start, String end) {
		
		Set<ShipPoint> sp = new HashSet<>();
		ShipPoint keyPoint = new ShipPoint(vessel, new ShipDate(start), new ShipDate(end));
		
		List<List<ShipPoint>> ll = shipMap.get(vessel);
		if(ll != null) { 
		  for(List<ShipPoint> ls: ll)
		  {	  
				int lSize = ls.size();
				int startInd = Collections.binarySearch(ls, keyPoint, keyPoint.getStartDate());
				if(startInd < 0) {
				  startInd = -startInd -1;	
				  if(startInd >= lSize)
					  continue;			 
				}
				
				int endInd = Collections.binarySearch(ls, keyPoint, keyPoint.getEndDate());
				if(endInd == -1)
					continue;
				
				endInd = -endInd +1;
				if(endInd >= lSize)
					endInd = lSize-1;
				
				sp.add(new ShipPoint(ls.get(startInd), ls.get(endInd)) );
		    		
		  }	
		}  
		return sp;
	}

	private void putShipPoint(ShipInterval si) {		 
		 Integer vessel = si.getVessel();
		 ShipPoint sp = new ShipPoint(vessel, si.getStart(),si.getEnd());
		 
		 List<List<ShipPoint>> ll = shipMap.get(vessel);
		 if(ll == null) { 
			 List<List<ShipPoint>> ln = new ArrayList<>();
			 List<ShipPoint> ls = new LinkedList<>();	 
			 ls.add(sp);
			 ln.add(ls);	
			 shipMap.put(vessel, ln);
		 }	 
		 else {
			 int indexStart =-1, indexEnd=-1;
			 Boolean exists = false;
			 
			 for(int i=0; i < ll.size(); i++) {
				 List<ShipPoint> ls = ll.get(i);
				 ShipPoint sPoint = ls.get(ls.size()-1);
				 
				 if(sPoint.getEnd().compareTo(si.getEnd()) == 0) {					
					 exists = true;
					 continue;
				 }	 
							 
				 if(sPoint.getEnd().compareTo(si.getStart()) == 0)						
					 indexStart = i;
				 
				 if(sPoint.getStart().compareTo(si.getEnd()) == 0)						
					 indexEnd = i;
				 
				 if(indexStart >= 0 && indexEnd >=0) 
					break;
			 }
			 
			 if(!exists) {
				 if(indexStart >= 0) {
					 ll.get(indexStart).add(sp); 
					 if(indexEnd >= 0) {
						 ll.get(indexStart).addAll(ll.get(indexEnd));	       	 
						 ll.remove(indexEnd);
					 }
				 }
				 else {
					 if(indexEnd >= 0)
						 ll.get(indexEnd).add(0, sp);
					 else {
						 List<ShipPoint> ls = new LinkedList<>();
						 ls.add(sp);
					     ll.add(ls);
				         shipMap.put(vessel, ll);
					 }    
			     }
			 }
		 }
			 
	 }
	
	
}
