package com.shipment.historical.controller;

import java.util.HashSet;
import java.util.List;
import java.util.Set;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.shipment.historical.model.ShipInterval;
import com.shipment.historical.model.ShipPoint;
import com.shipment.historical.service.ShipService;

@RestController
public class ShipController {
	
	@Autowired
	private ShipService shipService;
	
	@PutMapping("/api/points/{start0}/{end0}")	
	public Set<ShipPoint> getHistoricalData(@RequestBody List<ShipInterval> shipIntervals, @PathVariable String start0, @PathVariable String end0)
	{
        Set<ShipPoint> sp = new HashSet<>();
        String start = start0.replace(".", "/");
        String end = end0.replace(".", "/");
		
		shipService.createMap(shipIntervals, start, end);
		
		for(Integer i: shipService.getMapKeys()) {
			sp.addAll(shipService.getHistoricalAisData(i, start, end));
		} 	
		return sp;
	}
}
